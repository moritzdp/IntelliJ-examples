public class Hello {

    public static void main(String[] args) {
        System.out.println("Hello, Tim");

        int myFirstNumber = (10 + 5) + (2 * 10);
        System.out.println(myFirstNumber);
    }
}
